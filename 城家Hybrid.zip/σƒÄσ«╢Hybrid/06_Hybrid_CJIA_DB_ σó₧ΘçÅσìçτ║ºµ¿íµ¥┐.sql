begin;

use `cjia_db`;


  /*租户端 Android 平台消息频道升级*/
  INSERT INTO `updateversion` (appCode, channelCode, lastestVersion, supportVersion, downloadUrl, status,remark,createBy, createAt,modifyBy,modifyAt)  VALUES
  	( 'Tenement-Android', 'message', '2.0.17', '1.0.0~2.1.0', 'http://image.cjbnb.com/hybrid/message/message.zip', 'EBL','消息频道升级测试', 'dev',NOW(),'dev',NOW());

  /*租户端 IOS 平台消息频道升级*/
  INSERT INTO `updateversion` (appCode, channelCode, lastestVersion, supportVersion, downloadUrl, status,remark,createBy, createAt,modifyBy,modifyAt)  VALUES
     ( 'Tenement-iOS', 'message', '2.0.17', '1.0.0~2.1.0', 'http://image.cjbnb.com/hybrid/message/message.zip', 'EBL','消息频道升级测试', 'dev',NOW(),'dev',NOW());

   /*sql执行记录*/
  INSERT INTO `updateversionhistory` (appCode, channelCode, lastestVersion, supportVersion, downloadUrl, status,remark,createBy, createAt,modifyBy,modifyAt)  VALUES
   	( 'Tenement-Android', 'message', '2.0.17', '1.0.0~2.1.0', 'http://image.cjbnb.com/hybrid/message/message.zip', 'EBL','消息频道升级测试', 'dev',NOW(),'dev',NOW());

  INSERT INTO `updateversionhistory` (appCode, channelCode, lastestVersion, supportVersion, downloadUrl, status,remark,createBy, createAt,modifyBy,modifyAt)  VALUES
      ( 'Tenement-iOS', 'message', '2.0.17', '1.0.0~2.1.0', 'http://image.cjbnb.com/hybrid/message/message.zip', 'EBL','消息频道升级测试', 'dev',NOW(),'dev',NOW());

commit;
