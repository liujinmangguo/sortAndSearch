#城家 Hybrid 技术方案  （一期）

## 提纲
- **开发资源**
- **Hybrid 应用目录结构**
- **Hybrid 增量更新方案**
- **WEBview 与 Native 通信方案**
- **Hybrid 应用打包方案**
- **直联 WEBAPP 优化方案**
- **WEBview 异常处理**
- **view 后退处理**
- **webView 跳转 Native UIView**
- **基础功能**

----
## 开发资源

| 平台       |     数量 |   工时（人日）   |   姓名   |
| :-------- | --------:| :------:       | :------: |
| 服务端     |   1      |  2            |  潘鹏       |
| WEB 前端  |   1     |  5            |  薛梦飞  |
| IOS 客户端    |   2   |  16            |  张松松、黄烨  |
| Android 客户端    |   2 |  16          |  唐俊豪、陈海鸟  |

## Hybrid 应用目录结构
- IOS

![Alt text](./imgs/IOS+目录结构.png)

- Android

![Alt text](./imgs/Android+目录结构.png)

##  Hybrid 增量更新方案

**1. 增量包获取流程**

  ![Alt text](./imgs/Hybrid增量包获取流程.png)

**2. Hybrid 增量包升级流程**

  - **目标：** 以不影响用户使用现有功能为前提，静默升级
  - **风险：**升级失败导致原有功能缺失或功能异常
  - **解决方案：**升级过程中clone webapp 目录， 重启应用后重新指定新 webapp 目录    
  - **升级异常处理**：
    - 增量包下载失败 : 无提示，提交日志
    - 解压缩失败 : 无提示，删除升级包,提交日志
    - 空间不足 ：无提示，提交日志

  ![Alt text](./imgs/Hybird增量包升级流程.png)
**3. 压缩包**
  - 压缩包类型为zip
  - 压缩包须直接将该频道需要使用到的文件进行压缩，不可将需要的文件放置到文件夹后，对文件夹进行压缩
  - 升级包须以频道名为压缩包名称，如：ChannelA.zip

**4. 增量包发布记录**  
  **服务端表**  

| 应用名称   | 频道名称 |  当前版本 | 升级版本规则 | 是否全量替换 | 发布日期  | 发布内容 | 下载地址 |
| :------- | :-----   | :------:  | :-----       | :-----       | :-----    | :-----   | :----- |
| cjia        | APT      |  2.0.1    | 规则见下表   | Y            | 2006/2/15 | xxxxx描述|   . |  

  **客户端表：**

| 频道名称 |  频道当前版本 | 升级版本规则 | 是否全量替换 | 发布日期  | 下载地址 | 升级成功|
| :-----   | :------:  | :-----       | :-----       | :-----    |:----- |:----- |
| APT      |  2.0.1    | 规则见下表   | Y  (第一期仅支持全量)          | 2006/2/15 |    . |  状态位说明见下表 |

**5. 版本升级规则**

| 规则  | 含义         | 范例 |
| :---:  | :---        | :--- |
| ,     | 指定多个版本 | 1.2.3, 1.3.1 |
| ~     | 指定版本范围 | 1.1.1~1.3.1|

**6. 升级成功状态位规则**
- *0* : 需下载升级包
- *1* : 升级包已下载，等待解压
- *2* : 包解压成功，等待频道升级
- *3* : 升级成功


**7. 版本规范**

  - **版本格式**： 主版本号.次版本号.修订号
    1. 主版本号：业务重大调整
    2. 次版本号：基于现有业务新增、移除、调整产品功能、技术改进
    3. 修订号：bug 修复

  - **版本号比较规则**
    - 版本号由整型数字组成，最高4位（即 9999）
    - 不足三位，缺位补零(‘0’)
    - 超出三位，无效版本
    - 连点，无效版本
    - 版本比较顺序依次为 : 1主版本号, 2次版本号，3修订号
**8. 升级包条件**
  - 符合版本范围 或 升级成功标识为 0

## WEBview 与 Native 通信方案
为统一bridge接口实现 ，故此 Android平台弃用 addJavascriptInterface 方法，转而采用 iOS 平台相同的 伪协议方案
风险：直联第三方页面通过约定 API 进行恶意攻击
解决方案: 增加白名单，限制访问域，Native birdge API 执行时首先匹配消息来源
![Alt text](./imgs/通信方案.png)

## Hybrid  应用包与 WEBAPP 包的区别
- WEBAPP 包内所有静态资源文件（HTML、js、css、img）在打包时会更新文件名hash值。
- Hybrid APP 包内所有静态资源文件在打包时不 添加/更新 文件名内的hash值，以便于增量更新（减少更新关联文件，避免冗余文件）。
- WEBAPP 包以文件夹形式释出
- Hybrid APP 包以 zip 包形式释出

## 直联 WEBAPP 优化方案
- webview 在直联 webapp 时，首先由 webview 阻断前端框架 http 请求，而后注入本地 Hybrid 框架。
- web server 添加 MIME 类型（text/cache-manifest  .appcache），以支持 H5 Application Cache
- 开启Android webview 缓存，以支持 H5 Application Cache

## WEBview 异常处理
- Native 侦听网络状态，当网络失效时展示异常页面
- Document 响应 40X 时 Native 展示异常页面
- Document 响应 50X 时 Native 展示异常页面

## webView 跳转 Native UIView
- Native -> WebAPP

![Alt text](./imgs/Native 跳转到 WebAPP.png)

- WebAPP -> Native

![Alt text](./imgs/WebAPP 跳转 Native.png)

- WebAPP -> WebAPP

![Alt text](./imgs/WebAPP 跳转 WebAPP.png)

## view 后退处理
- Android 物理键后退，webview History 栈优先
- History 栈为空时，交由 Native 进行 UIView 后退
- 当络异常页面为当前活动页面时，后退操作忽略 webview History 栈，直接进行 UIView 后退

![Alt text](./imgs/View 后退处理.png)


## 基础功能
- 页面跳转
- 获取用户登录信息（用户详情）
- 支付
- 请求头
- 环境信息（设备、网络等信息）
- 数据缓存
